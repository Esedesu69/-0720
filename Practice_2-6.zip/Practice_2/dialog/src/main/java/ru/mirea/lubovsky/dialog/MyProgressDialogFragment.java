package ru.mirea.lubovsky.dialog;

public class MyProgressDialogFragment {
}
